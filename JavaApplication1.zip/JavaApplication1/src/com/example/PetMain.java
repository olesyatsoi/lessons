package com.example;
import com.example.domain.Animal;
import com.example.domain.Spider;
import com.example.domain.Fish;
import com.example.domain.Cat;
import com.example.domain.Pet;
       
public class PetMain {

    
    public static void main(String[] args) {
 Spider s = new Spider(); 
 s.eat(); 
 s.walk(); 
 Cat c = new Cat("Tom"); 
 c.eat(); 
 c.walk(); 
 c.play(); 
 Cat a = new Cat(); 
 a.eat(); 
 a.walk(); 
 Pet p; 
 p = new Cat(); 
 p.setName("Mr. Whiskers"); 
 p.play(); 
 Fish f = new Fish(); 
 f.setName("Guppy"); 
 f.eat(); 
 f.walk(); 
 f.play();
 
 Fish d = new Fish(); 
 d.eat();
 d.walk(); 

    }
  
}
