package com.example.domain;
public class Fish extends Animal implements Pet { 
 
public String name; 
 
    /**
     *
     * @param name
     */
    public Fish(String name) { 
 super(4); 
 this.name = name; 
 } 
 public Fish() {
     this("Гуппи");
   }
 
    /**
     *
     * @return
     */
    @Override
    public String getName() { 
 return name; 
 } 

    /**
     *
     * @param name
     */
    @Override
 public void setName(String name) { 
 this.name = name; 
 } 
 @Override 
 public void play() { 
 System.out.println("Рыбка просто плавает"); 
 } 
@Override 
 public void eat() { 
 System.out.println("Рыбки едят червяков"); 
 }
 @Override 
 public void walk() { 
 System.out.println("Рыбки, конечно, гулять не могут – они плавают"); 
 } 
} 
